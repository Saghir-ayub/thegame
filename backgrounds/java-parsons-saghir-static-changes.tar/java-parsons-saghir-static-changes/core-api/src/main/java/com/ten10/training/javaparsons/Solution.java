package com.ten10.training.javaparsons;

public interface Solution {

    /**
     * Compile and run the solution and return true if successfully compiled.
     */
    boolean evaluate();
}
